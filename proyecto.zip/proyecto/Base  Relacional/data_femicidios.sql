--------------------------------------------------------
-- Archivo creado  - martes-febrero-05-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table AGRESOR
--------------------------------------------------------

  CREATE TABLE "FEMICIDIOS"."AGRESOR" 
   (	"ID_AGRESOR" NUMBER(3,0), 
	"NOMBRE_AGRESOR" VARCHAR2(100 BYTE), 
	"APELLIDOS_AGRESOR" VARCHAR2(100 BYTE), 
	"EDAD_AGRESOR" NUMBER(2,0), 
	"NACIONALIDAD_AGRESOR" VARCHAR2(20 BYTE), 
	"OCUPACI�N_AGRESOR" VARCHAR2(20 BYTE), 
	"SITUACI�N_AGRESOR" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table BARRIO
--------------------------------------------------------

  CREATE TABLE "FEMICIDIOS"."BARRIO" 
   (	"ID_BARRIO" VARCHAR2(3 BYTE), 
	"COLUMN1" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table DEPARTAMENTO
--------------------------------------------------------

  CREATE TABLE "FEMICIDIOS"."DEPARTAMENTO" 
   (	"ID_DEPARTAMENTO" VARCHAR2(20 BYTE), 
	"DEPARTAMENTO" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table FEMICIDIO
--------------------------------------------------------

  CREATE TABLE "FEMICIDIOS"."FEMICIDIO" 
   (	"ID_FEMICIDIO" NUMBER(2,0), 
	"FECHA_FEMINICIDIO" VARCHAR2(10 BYTE), 
	"MES" NUMBER(2,0), 
	"A�O" NUMBER(4,0), 
	"HOR_MUERTE" VARCHAR2(5 BYTE), 
	"LUGAR_FEMINICIDIO" VARCHAR2(42 BYTE), 
	"ID_PROVINCIA" NUMBER, 
	"ID_BARRIO" VARCHAR2(20 BYTE), 
	"ID_PAIS" VARCHAR2(20 BYTE), 
	"ID_DEPARTAMENTO" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table JUICIO
--------------------------------------------------------

  CREATE TABLE "FEMICIDIOS"."JUICIO" 
   (	"NRO" NUMBER(2,0), 
	"CASO" VARCHAR2(29 BYTE), 
	"SENTENCIA" VARCHAR2(37 BYTE), 
	"TESTIGOS" VARCHAR2(5 BYTE), 
	"ARMA" VARCHAR2(15 BYTE), 
	"CAUSA" VARCHAR2(19 BYTE), 
	"VICTIMA_AGRESOR" NUMBER(3,0), 
	"FEMICIDIO" NUMBER(3,0)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table NOTICIA
--------------------------------------------------------

  CREATE TABLE "FEMICIDIOS"."NOTICIA" 
   (	"ID_NOTICIA" NUMBER(*,0), 
	"URL" VARCHAR2(230 BYTE), 
	"FECHA_UR" VARCHAR2(108 BYTE), 
	"TEXTOCOMPLETO_URL" VARCHAR2(1892 BYTE), 
	"AUTOR" VARCHAR2(24 BYTE), 
	"CATEGORIA" VARCHAR2(9 BYTE), 
	"PALABRAS" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table NOTICIA_FEMICIDIO
--------------------------------------------------------

  CREATE TABLE "FEMICIDIOS"."NOTICIA_FEMICIDIO" 
   (	"ID_NOTICIA_FEMICIDIO" VARCHAR2(3 BYTE), 
	"ID_NOTICIA" VARCHAR2(3 BYTE), 
	"FEMICIDIO" NUMBER(3,0)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table PAIS
--------------------------------------------------------

  CREATE TABLE "FEMICIDIOS"."PAIS" 
   (	"ID_PAIS" VARCHAR2(4 BYTE), 
	"PAIS" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table PALABRAS
--------------------------------------------------------

  CREATE TABLE "FEMICIDIOS"."PALABRAS" 
   (	"ID_PALABRAS" VARCHAR2(20 BYTE), 
	"COLUMN1" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table PROVINCIAS
--------------------------------------------------------

  CREATE TABLE "FEMICIDIOS"."PROVINCIAS" 
   (	"ID_PROVINCIA" NUMBER(2,0), 
	"PROVINCIA" VARCHAR2(50 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table VICTIMA
--------------------------------------------------------

  CREATE TABLE "FEMICIDIOS"."VICTIMA" 
   (	"ID_VICTIMA" NUMBER(2,0), 
	"NOMBRE_VICTIMA" VARCHAR2(100 BYTE), 
	"APELLIDOS_VICTIMA" VARCHAR2(100 BYTE), 
	"EDAD_VICTIMA" VARCHAR2(3 BYTE), 
	"NACIONALIDAD_VICTIMA" VARCHAR2(20 BYTE), 
	"OCUPACION_VICTIMA" VARCHAR2(50 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table VITIMA_AGRESOR
--------------------------------------------------------

  CREATE TABLE "FEMICIDIOS"."VITIMA_AGRESOR" 
   (	"ID_VICTIMA_AGRESOR" NUMBER(2,0), 
	"ID_VICTIMA" NUMBER(2,0), 
	"ID_AGRESOR" NUMBER(2,0), 
	"RELACI�N_V�CTIMA" VARCHAR2(7 BYTE), 
	"TIEMPO_RELACI�N" VARCHAR2(4000 BYTE), 
	"AGRESION_PREVIA" VARCHAR2(382 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into FEMICIDIOS.AGRESOR
SET DEFINE OFF;
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('1','David','Concepci�n "N"? ','23','Mexicano','Desconocido','Detenido');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('2','Grupo delicuentes',null,'53',null,'Desconocido','Profugos');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('3',null,null,'44',null,'Desconocido','Profugos');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('4','Melisa','N','22','Mexicana','Desconocido','Detenido');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('5','Yoen El�s','N','63','Mexicano','Desconocido','Detenido');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('6',null,null,'32','Mexicano','Desconocido','Detenido');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('7',null,null,'50','Mexicano','Desconocido','Detenido');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('8',null,null,'28','Mexicano','Desconocido','Detenido');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('9',null,null,'43','Mexicano','Desconocido','Detenido');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('10',null,null,'25','Mexicano','Desconocido','Detenido');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('11',null,null,'33','Mexicano','Desconocido','Detenido');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('12','Gloria Karina ',null,'38','Mexicana','Desconocido','Detenida');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('13',null,null,'33','Mexicana','Desconocido','Profugos');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('14',null,null,'27','Mexicana','Desconocido','Profugo');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('15',null,null,'21','Mexicano','Desconocido','Desconocido');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('16',null,null,'56','Mexicano','Desconocido','Profugos');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('17',null,null,'40','Mexicano','Desconocido','Detenido');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('18',' V�ctor Manuel','Cardenas',null,'Mexicano','Desconocido','Profugo');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('19',null,null,'33','Mexicano','Desconocido','Profugo');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('20',null,null,'27','Mexicano','Desconocido','Profugo');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('21',null,null,'21','Mexicano','Desconocido','Profugo');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('22',null,null,null,'Mexicana','Desconocido','Desconocido');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('23','Luis','Torres','25','Mexicana','Desconocido','Desconocido');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('24',null,null,'33','Mexicana','Desconocido','Desconocido');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('25',null,null,null,'Mexicano','Desconocido','Desconocido');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('26',null,null,'22','Mexicano','Desconocido','Profugo');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('27',null,null,'63','Mexicano','Desconocido','Desconocido');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('28',null,null,'32','Mexicano','Desconocido','Desconocido');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('29',null,null,null,'Mexicano','Desconocido','Desconocido');
Insert into FEMICIDIOS.AGRESOR (ID_AGRESOR,NOMBRE_AGRESOR,APELLIDOS_AGRESOR,EDAD_AGRESOR,NACIONALIDAD_AGRESOR,"OCUPACI�N_AGRESOR","SITUACI�N_AGRESOR") values ('30',null,null,null,'Mexicano','Desconocido','Desconocido');
REM INSERTING into FEMICIDIOS.BARRIO
SET DEFINE OFF;
REM INSERTING into FEMICIDIOS.DEPARTAMENTO
SET DEFINE OFF;
REM INSERTING into FEMICIDIOS.FEMICIDIO
SET DEFINE OFF;
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('3','05-11-2018','11','2018',null,'El Tamarindo','3',null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('4','13-11-2018','11','2018',null,'Tlatelolco en la alcald�a de Cuauht�moc.',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('5','22-11-2018','11','2018','5:30','Playas de Rosarito,Baja California',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('6','27-11-2018','11','2018','15:30','El Salero',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('7','28-11-2018','11','2018','16:30','El Salero',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('8','30-11-2018','11','2018','4:00','Aguascalientes',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('9','17-11-2018','11','2018','7:49','San Salvador de Arriba',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('10','24-11-2018','11','2018','7:50','Maravillas',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('11','6-11-2018','11','2018','14:05','San Salvador de Arriba',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('12','04-11-2018','11','2018',null,'San Luis R�o Colorado, Sonora',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('13','14-11-2018','11','2018',null,'Puebla',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('14','09-11-2018','11','2018',null,'Tehuacan',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('15','07-11-2018','11','2018',null,'Naupan',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('16','09-11-2018','11','2018',null,'Ecatepec de Morelos',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('17','29-11-2018','11','2018',null,'Lago Michigan',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('18','19-11-2018','11','2018',null,null,null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('19','01-11-2018','11','2018',null,'Ecatepec de Morelos',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('20','02-11-2018','11','2018',null,'Tepito',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('21','24-11-2018','11','2018',null,'Venustiano Carranza',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('22','07-11-2018','11','2018',null,'Tultitl�',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('23','05-11-2018','11','2018',null,'Ciudad Cuauht�moc',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('24','07-11-2018','11','2018',null,'Oaxaca',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('25','07-11-2018','11','2018',null,'Oaxaca',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('26','20-11-2018','11','2018','14:55','Olinal�',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('27','06-11-2018','11','2018','18:19','Aguililla',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('28','17-11-2018','11','2018','20:32','Jer�cuaro',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('29','17-11-2018','11','2018','20:32','Jer�cuaro',null,null,null,null);
Insert into FEMICIDIOS.FEMICIDIO (ID_FEMICIDIO,FECHA_FEMINICIDIO,MES,"A�O",HOR_MUERTE,LUGAR_FEMINICIDIO,ID_PROVINCIA,ID_BARRIO,ID_PAIS,ID_DEPARTAMENTO) values ('30','05-11-2018','11','2018','4:36','uan Jose Torres Landa, Le�n',null,null,null,null);
REM INSERTING into FEMICIDIOS.JUICIO
SET DEFINE OFF;
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('2','En investigacion',null,null,'Arma de Fuego','Disparada',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('3','Desconocido',null,null,'Desconocida','Asesinada',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('5','Detenido',null,null,'Desconocida','Homicidio',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('6','Detenido',null,null,'Desconocida','Agresion',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('7','Detenido',null,null,'Arma de Fuego','Agresion',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('8','Detenido',null,null,'Desconocida','Agresion',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('9','Detenido',null,null,'Desconocida','Agresion',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('10','Detenido',null,null,'Desconocida','Agresion',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('11','Detenido',null,null,'Arma de Fuego','Agresion',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('12','Detenida',null,null,'Desconocida','Asesinato',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('13','Desconocido',null,null,'Arma de Fuego','Asesinato',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('14','Desconocido',null,null,'Desconocida','Asesinato',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('15','Desconocido',null,null,'Golpes Humanos','Golpes Fisicos',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('16','Desconocido',null,null,'calcinada','calcinada',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('17','Detenido',null,null,'Inoacto de bala','Asesinato',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('19','Profugo',null,null,'Arma de Fuego','Disparada en Cabeza',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('20','Profugo',null,null,'Arma de Fuego','Asesinada a Balazos',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('21','Desconocido',null,null,'Arma de Fuego','Asesinada',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('22','Desconocido',null,null,'Arma de Fuego','Asesinada',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('23','Desconocido',null,null,'Arma Blanca','Asesinada',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('24','Desconocido',null,null,'Arma de Fuego','Asesinada',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('25','Desconocido',null,null,'Arma de Fuego','Asesinada',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('26','Profugo',null,null,'Arma de Fuego','Asesinada',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('27','Desconocido',null,null,'Arma de Fuego','Asesinada',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('28','Desconocido',null,null,'Arma Blanca','Asesinada',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('29','Desconocido',null,null,'Arma Blanca','Asesinada',null,null);
Insert into FEMICIDIOS.JUICIO (NRO,CASO,SENTENCIA,TESTIGOS,ARMA,CAUSA,VICTIMA_AGRESOR,FEMICIDIO) values ('30','Desconocido',null,null,'Arma de Fuego','Homicidio',null,null);
REM INSERTING into FEMICIDIOS.NOTICIA
SET DEFINE OFF;
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('1','feminicidiosmx.crowdmap.com/reports/view/5163','13/02/201805:01 p.m.','eg�n informes policiales, a eso de las 21:00 horas de este domingo, elementos de la Polic�a Municipal Preventiva fueron alertados que en el hospital regional hab�an ingresado a una mujer ya muerta.

Por este motivo, un grupo de uniformados se desplazaron hasta el lugar de los hechos y ah� se entrevistaron con Francisco A., B., quien dijo ser el cu�ado de la occisa Mar�a Reyes "N"?, la cual hab�a sido victimada a pu�aladas por su propio hijo. E inclusive el matricida hab�a llegado al Hospital Regional, donde fue localizado por Elementos de la Direcci�n de Seguridad P�blica local y llevado a los separos.

Sobre la forma en que perdi� la vida la ama de casa, se refiere que �sta se encontraba descansando cuando lleg� su hijo David Concepci�n M. de 23 a�os, quien se encontraba bajo los efectos del alcohol y posiblemente alguna droga, le comenz� a exigir dinero para seguir en la parranda.

No obstante, como �sta se neg� a entregarle lo que ped�a, David se dirigi� a la cocina donde tom� un cuchillo con el que la atac� hasta que cay� mortalmente herida al suelo, donde fue encontrada por otro de sus hijos, quien la llev� r�pidamente al nosocomio pero �sta muri� antes de ser ingresada.',null,null,null);
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('3','https://www.tribuna.com.mx/Los-macabros-feminicidios-que-estremecieron-a-Mexico-este-2018-t201812240002.html','25 de Diciembre 2018 � 20:30 hs',null,null,'Seguridad',null);
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('4',null,'https://www.tribuna.com.mx/Los-macabros-feminicidios-que-estremecieron-a-Mexico-este-2018-t201812240002.html','El pasado 13 de noviembre vecinos de la Calzada Nonoalco 181 encontraron el cad�ver de una menor de 14 a�os identificada como Ingrid Alison dentro de una maleta en la Unidad Habitacional Tlatelolco en la alcald�a de Cuauht�moc.

Autoridades investigaron a Melisa ''N'', de 22 a�os como la principal sospechosa en el asesinato de la adolescente de 14 a�os, pues seg�n la madre de la v�ctima, ambas sosten�an una relaci�n sentimental.

Pese a esta teor�a, se hizo viral un video de las c�maras de vigilancia, en el cual aparece un sujeto que presuntamente llevaba los restos de la menor en la maleta con el objetivo de abandonarlos.',null,null,null);
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('5','https://www.google.com/maps/d/viewer?mid=174IjBzP-fl_6wpRHg5pkGSj2egE1=32.36032905397765%2C-116.926003833626051=12','22/11/2018','PLAYAS DE ROSARITO .- Agentes de la Polic� Ministerial del Estado, de la Subprocuradur� de Zona de Playas de Rosarito, detuvieron a Yoen El�s N, alias “El Nosek�?, por contar con una orden de aprehensi�n por el delito de homicidio calificado.

En fecha 22 de noviembre de 2017, siendo aproximadamente las 05:30 horas, sobre el Boulevard 2000, a la altura del kilometro 29, con direcci�n de Rosarito a Tijuana, agentes de la Polic� Municipal localizaron a una persona del sexo femenino sin vida; el cuerpo presentaba sangre en la nariz y hab� un casquillo al lado de su cabeza; agentes adscritos a la Unidad de Homicidios realizaron inspecci�n y levantamiento del cad�ver.


Derivado de la investigaci�n realizada por la Polic� Ministerial del Estado y el Fiscal, se obtuvo la identidad de la v�ctima de nombre Melissa Abigail de 19 a�os de edad, con domicilio en la ciudad de Tijuana, as� como tambi�n se obtuvieron todas las pruebas necesarias para poder determinar la presunta responsabilidad penal dentro del expediente del ahora imputado de nombre Yoen El�s N, alias “El Nosek�?.

El 27 de marzo de 2018 se celebr� audiencia privada para solicitar orden de aprehensi�n en contra de Yoen El�s N., por el delito de Homicidio Calificado cometido con Premeditaci�n y Ventaja en agravio de la v�ctima Melissa Abigail.

La cual fue otorgada en los t�rminos solicitados bajo la Causa Penal 84/18 y el 2 de abril de 2018 se cumpliment� la orden de aprehensi�n por parte de la Polic� Ministerial del Estado, zona Playas de Rosarito; quien lo intern� en el Centro de Reinserci�n Social de La Mesa, quedando a disposici�n del Juez Mixto de Primera Instancia de �ste Partido Judicial, para el proceso penal correspondiente.',null,null,null);
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('11',null,null,null,null,null,null);
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('12','https://www.google.com/maps/d/viewer?mid=174IjBzP-fl_6wpRHg5pkGSj2egE1=32.533663793583145%2C-113.818827817753171=9','04/11/2018','Freddy Mej� / Tribuna de San Luis Lunes 6 de noviembre de 2017 en Polic�ca
SLRC.- Alberto “N�?, de 38 a�os de edad y Gloria Karina “N�?, de 36 hoy ser�n acusados por el fiscal ante el Juez de Control del delito de feminicidio por la muerte por estrangulamiento de la joven Jessica Lizeth Ledezma Acosta, cuyos hechos se registraron el pasado s�bado en un domicilio de la avenida Santo Domingo y calle San Alberto, colonia Aviaci�n 2.

Como se informara, ambos fueron arrestados al ser sorprendidos quemando el cuerpo de Ledezma, que hab�n introducido en un agujero en el patio.
El fuego solo alcanz� a afectar las piernas por la oportuna llegada de elementos de la Direcci�n de Polic� y Tr�nsito, y Agencia Ministerial de Investigaci�n Criminal.
PUBLICIDAD



Los uniformados hab�n sido enterados por un testigo en torno a que “La Gloria�? le hab� manifestado que por la avenida San Francisco y calle San Felipe, frente a una tienda de abarrotes y como al mediod� hab�n levantado a “La Jessi�? y la hab�n asesinado en la casa de “El Beto�?.

Fue as� como r�pidamente se organiz� el operativo mediante el que la pareja fue sorprendida echando mas le�a a la hoguera que hab�n hecho en el patio, con intenci�n de desaparecer el cuerpo.
Para los vecinos fue sorpresiva la acci�n polic�ca a causa de que la vivienda casi no era habitada por “El Beto�?, quien hace tiempo se hab� separado de su esposa.

Durante las investigaciones no se ha podido establecer bien la causa del crimen, aunque la polic� sospecha que fue por problemas a�ejos entre “La Gloria�? y “La Jessi�?.
Hasta ayer tarde no se conoc� la hora exacta de la audiencia en la Primera Sala Oral en la que ser� acusada la pareja por el delito de feminicidio.',null,null,null);
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('13','https://www.periodicocentral.mx/2018/pagina-negra/feminicidios/item/27975-feminicidio-97-a-daniela-la-degollo-su-marido-frente-a-sus-hijos-en-xayacatlan-de-bravo?fbclid=IwAR3t9b70DZtGFbyfC4QZgNvtiZvM64ngp7TSpCVGp6K9YNUmrHtBWHNsVsg','11.12.2018','La mujer fue ejecutada cuando manejaba su camioneta VW Tiguan, el 14 de noviembre. Seg�n versiones de vecinos, los agresores le dispararon desde el autom�vil Renault Cl�o, placas TYW7298, de color gris. Tanto la mujer como su copiloto resultaron heridos, y aunque ella intent� seguir manejando, unos metros adelante se desvaneci�.

Leer M�s: https://www.periodicocentral.mx/2018/pagina-negra/feminicidios/item/27975-feminicidio-97-a-daniela-la-degollo-su-marido-frente-a-sus-hijos-en-xayacatlan-de-bravo?fbclid=IwAR3t9b70DZtGFbyfC4QZgNvtiZvM64ngp7TSpCVGp6K9YNUmrHtBWHNsVsg#ixzz5e4n8BEX7 
Follow us: @CentralPuebla on Twitter',null,null,null);
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('14','https://www.periodicocentral.mx/2018/pagina-negra/feminicidios/item/27975-feminicidio-97-a-daniela-la-degollo-su-marido-frente-a-sus-hijos-en-xayacatlan-de-bravo?fbclid=IwAR3t9b70DZtGFbyfC4QZgNvtiZvM64ngp7TSpCVGp6K9YNUmrHtBWHNsVsg','11.12.2018','El cuerpo de la mujer ocurri� el viernes 9 de noviembre, sobre la calle Salina Cruz y el tianguis de ropa del municipio, a unas cuadras de la morgue municipal. Se ignoran m�s caracter�sticas del cuerpo debido a que su avanzada descomposici�n es imposible encontrarlas, adem�s se desconoce la identidad de la mujer debido a que no se hall� alguna identificaci�n

Leer M�s: https://www.periodicocentral.mx/2018/pagina-negra/feminicidios/item/27975-feminicidio-97-a-daniela-la-degollo-su-marido-frente-a-sus-hijos-en-xayacatlan-de-bravo?fbclid=IwAR3t9b70DZtGFbyfC4QZgNvtiZvM64ngp7TSpCVGp6K9YNUmrHtBWHNsVsg#ixzz5e4o0d4my 
Follow us: @CentralPuebla on Twitter',null,null,null);
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('15','https://www.periodicocentral.mx/2018/pagina-negra/feminicidios/item/27975-feminicidio-97-a-daniela-la-degollo-su-marido-frente-a-sus-hijos-en-xayacatlan-de-bravo?fbclid=IwAR3t9b70DZtGFbyfC4QZgNvtiZvM64ngp7TSpCVGp6K9YNUmrHtBWHNsVsg','11.12.2018','El cuerpo de Claudia Hern�ndez Fonseca, de 35 a�os, fue localizado la ma�ana del 7 de noviembre en un basurero ubicado en el camino a Naupan, municipio de la Sierra Norte de Puebla. De acuerdo a la necropsia, la mujer muri� a causa de golpes que recibi� en la cabeza y no por las heridas de arma punzocortante que presentaba

Leer M�s: https://www.periodicocentral.mx/2018/pagina-negra/feminicidios/item/27975-feminicidio-97-a-daniela-la-degollo-su-marido-frente-a-sus-hijos-en-xayacatlan-de-bravo?fbclid=IwAR3t9b70DZtGFbyfC4QZgNvtiZvM64ngp7TSpCVGp6K9YNUmrHtBWHNsVsg#ixzz5e4oyUXKq 
Follow us: @CentralPuebla on Twitter',null,null,null);
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('16','https://www.google.com/maps/d/viewer?mid=174IjBzP-fl_6wpRHg5pkGSj2egE=19.4998734798487%2C-99.010973222699621=131=IwAR1IRiKBsS3ZD_ORZIuVr3UqtlAWzmFLqagXpLVs6l0OQxHdWfm6VU5P35s','22/11/2018','El cuerpo de una joven de 16 a�os de edad, quien fue secuestrada d�s antes, fue localizado en un terreno de la colonia Citlalc�atl, de este municipio, luego de que supuestamente la familia no lograra pagar el rescate que exig�n los secuestradores de la jovencita.

Reportes oficiales indican que fue cerca de la 1 de la tarde de ayer, cuando vecinos de la calle Huitzilopochtli reportaron a la polic� la presencia de un cuerpo que se encontraba totalmente calcinado.

Al lugar llegaron polic�s quienes sin identificar el cad�ver solicitaron la presencia de personal ministerial que orden� el levantamiento del cuerpo y su traslado al Semefo de Ecatepec donde m�s tarde se supo que se trataba de una jovencita que hab� sido secuestrada d�s antes.

Se inform� que el cuerpo corresponde a la menor de 16 a�os de nombre Jessica Serrano, quien fue ultimada de esta forma por los secuestradores luego de no recibir el pago por el rescate, el cual la familia no logr� juntar.

La joven habr� sido raptada en el municipio de Naucalpan, donde viv� con su familia.

Versiones indican que ante esto, los delincuentes enviaron a la familia videos captados en el momento en que la joven era calcinada, pero ser�n las autoridades quienes determinen la veracidad de lo ocurrido',null,null,null);
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('17','https://www.google.com/maps/d/viewer?mid=174IjBzP-fl_6wpRHg5pkGSj2egE=19.4998734798487%2C-99.01097322269962=13=IwAR1IRiKBsS3ZD_ORZIuVr3UqtlAWzmFLqagXpLVs6l0OQxHdWfm6VU5P35s','22/11/2018','El conductor, un hombre de aproximadamente 40 a�os quien tambi�n presentaba una herida por disparo de arma de fuego en la pierna derecha, indic� a las autoridades que en una ri�a afuera del domicilio de su acompa�ante, en la avenida de la Viga, los lesionaron varios sujetos en una supuesta pelea logrando escapar de los agresores.

El hombre que fue detenido en la esquina de la calle Lago Michigan y Lago Valencia en la colonia Ciudad Lago mencion� a los uniformados que estaba buscando un hospital, versi�n que no creyeron los uniformados quienes solicitaron el apoyo de m�s compa�eros y la asistencia de una ambulancia quien verific� la muerte de la mujer.

La zona fue acordonada por la polic� para facilitar los trabajos de los peritos quienes tomaron conocimiento de los hechos.

El conductor quien indic� a la polic� que no trabajaba como transporte p�blico, fue trasladado al ministerio p�blico de la Perla donde en las pr�ximas horas se determina su situaci�n legal relacionado con este posible feminicidio.',null,null,null);
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('21','https://www.google.com/maps/d/viewer?mid=174IjBzP-fl_6wpRHg5pkGSj2egE1=19.497514619491177%2C-99.00475523401111=121=IwAR1IRiKBsS3ZD_ORZIuVr3UqtlAWzmFLqagXpLVs6l0OQxHdWfm6VU5P35s','11.12.2018','La madre de la joven hab� reportado que la �ltima vez que tuvo contacto con ella fue la noche del jueves 16, cuando viaj� de Quer�taro a Puebla y supuestamente se hosped� en el hotel Punta Palmas en esta ciudad.

La joven radicaba desde hace casi tres a�os en la ciudad de Quer�taro, pero viajar� ese d� a Puebla para prestar el servicio de escort o acompa�ante, actividad a la que se dedicaba con un hombre que la hab� contratado.

De acuerdo con la madre, desde ese d� perdi� contacto con su hija, pues a pesar de que le marc� insistentemente al celular durante toda la noche, el aparato estaba apagado.

El cad�ver de la joven fue localizado desde el viernes anterior en la habitaci�n 107 del hotel Platino, ubicado en la delegaci�n Venustiano Carranza en la Ciudad de M�xico.

Seg�n reportes extraoficiales, Gibson Jaimes estaba desnuda, maniatada y amordazada, as� como con diversas lesiones en cuerpo y cuello.

Fue hasta este d� que la Fiscal� de Puebla confirm� que se trata de la joven reportada como desaparecida en esta entidad, pues cuenta con dos tatuajes que fueron descritos por su madre como se�as particulares.



Sus amigas hab�n presentado una denuncia por su desaparici�n ante la Fiscal� de Justicia de Puebla.

Ten� una ni�a. En ese estado fue vista por �ltima vez por sus conocidos, quienes indicaron que se hosped� en el hotel Punta Palmas, tras viajar desde Quer�taro, donde viv� con su madre e hija de 5 a�os. La v�ctima fue identificada por los tatuajes que ten�: uno detr�s de la oreja con el nombre de "Arianis", otro m�s en la mano izquierda que dice "Nicolle" y el tercero, una rosa roja en la zona p�lvica. Al momento de su desaparici�n la joven, quien supuestamente era escort, usaba un vestido, zapatillas y una bolsa, todo de color negro.',null,null,null);
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('22','https://www.google.com/maps/d/viewer?mid=174IjBzP-fl_6wpRHg5pkGSj2egE1=19.51843507631567%2C-99.065866684206411=121=IwAR1IRiKBsS3ZD_ORZIuVr3UqtlAWzmFLqagXpLVs6l0OQxHdWfm6VU5P35s','11.12.2018','Fuentes locales informaron que alrededor de las 22:20 horas de ayer una llamada an�nima alert� a la polic� municipal sobre una camioneta en la que viajaban sujetos, quienes abandonaron un bulto en el asfalto, en la esquina de calle Matamoros con avenida Centenario, en dicha comunidad de Tultitl�n.

Afirmaron que polic�s acudieron al sitio y detectaron la bolsa negra, dentro de la cual estaba el cuerpo de una mujer, de aproximadamente 30 a�os de edad, envuelto en una cobija roja','MSM Noticias','Noticias',null);
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('23','https://www.google.com/maps/d/viewer?mid=174IjBzP-fl_6wpRHg5pkGSj2egE1=15.685442024181627%2C-92.458652180457531=91=IwAR1IRiKBsS3ZD_ORZIuVr3UqtlAWzmFLqagXpLVs6l0OQxHdWfm6VU5P35s','15/12/2018','Campesinos que transitaban por un terreno bald�o conocido como El Nanzar, ubicado en el ejido El Sabinalito del municipio de Frontera Comalapa, hallaron restos �seos aparentemente de una mujer.

Los lugare�os solicitaron la presencia de un Ministerio P�blico y de peritos de la Fiscal� General del Estado (FGE), para realizar el levantamiento de los restos de una mujer, quien al parecer habr� desaparecido desde hace dos meses.

Hasta el lugar, un terreno bald�o cercano a la l�nea fronteriza con Guatemala, lleg� Adolfo Salas S�nchez, de 58 a�os de edad, quien mencion� que al parecer se trataba de los restos de su hija quien se encontraba enferma de sus facultades mentales y habr� desaparecido desde el pasado 19 de marzo.

Por las caracter�sticas de la ropa encontrada en el lugar, el padre de la v�ctima identificada con el nombre de Mar� del Carmen Salas P�rez, de 26 a�os de edad, identific� que se trataba de ella, pero ser�n las autoridades ministeriales quienes dictaminen s� la osamenta pertenec� a la joven o no.

Seg�n coment� el afectado, la joven sol� salir de su domicilio y despu�s de algunas horas regresar, sin embargo, el pasado 19 de marzo no regres� por lo que comenzaron a buscarla sin lograr el objetivo. Por su parte, autoridades iniciaron con las investigaciones correspondientes de los hechos, pues jam�s fue reportada su desaparici�n.',null,null,null);
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('24','https://www.google.com/maps/d/viewer?mid=174IjBzP-fl_6wpRHg5pkGSj2egE1=16.85491426372008%2C-95.706663172243221=91=IwAR1IRiKBsS3ZD_ORZIuVr3UqtlAWzmFLqagXpLVs6l0OQxHdWfm6VU5P35s','15/12/2018','Tres asesinados en un d� en el Istmo, Oaxaca
L�der de la CTM detenido por masacre en Totol�pam, Oaxaca
Buscaban cad�ver de una ni�a y apareci� un hombre
DISPUTA DE UN TERRENO

De acuerdo con el informe de la polic�, los hechos ocurrieron a las 13.30 horas de ayer en el paraje El Higo de la agencia municipal del Zapote perteneciente a Miahuatl�n de Porfirio D�z.

Una familia arrib� al lugar para visitar su predio, pero en el mismo sitio estaban otras personas con quienes disputan el terreno.

En el sitio se hicieron de palabras, pero de pronto uno de los que reclaman el predio sac� un arma de fuego y realiz� varias detonaciones de arma de fuego.

Tres impactos alcanzaron a la peque�a de un a�o con cinco meses, de nombre Graciela Daniela y quien fue auxiliada y canalizada al hospital del Instituto Mexicano del Seguro Social de Miahuatl�n de Porfirio D�z.

En el lugar quedaron sin vida tres personas, quienes fueron identificadas como Jacinto Maurilio R.S., de 60 a�os de edad; Angelina G.G., de 30 a�os, y Cristina R.S., de 48 a�os de edad.','Los Femicidios en Mexico',null,null);
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('25','https://www.google.com/maps/d/viewer?mid=174IjBzP-fl_6wpRHg5pkGSj2egE=16.85491426372008%2C-95.706663172243221=91=IwAR1IRiKBsS3ZD_ORZIuVr3UqtlAWzmFLqagXpLVs6l0OQxHdWfm6VU5P35s','15/12/2018','Tres asesinados en un d� en el Istmo, Oaxaca
L�der de la CTM detenido por masacre en Totol�pam, Oaxaca
Buscaban cad�ver de una ni�a y apareci� un hombre
DISPUTA DE UN TERRENO

De acuerdo con el informe de la polic�, los hechos ocurrieron a las 13.30 horas de ayer en el paraje El Higo de la agencia municipal del Zapote perteneciente a Miahuatl�n de Porfirio D�z.

Una familia arrib� al lugar para visitar su predio, pero en el mismo sitio estaban otras personas con quienes disputan el terreno.

En el sitio se hicieron de palabras, pero de pronto uno de los qtas o pleitos, no le dieron importancia, hasta que alguien se asom� m�s tarde y encontr� a una mujer muerta, d�ndole aviso a la polic�.

Antes que llegaran las patrullas al lugar del incidente, algunos de los vecinos pudieron ver de cerca a la fallecida y la reconocieron como Ang�lica “N�? misma que viv� a 2 cuadras de donde muri�, coincidiendo en que desde hace unos meses que ten� problemas con su ex-pareja, presumiblemente porque la golpeaba mucho y por celos. De lo cual ahora que estaba sin vida y con huellas de golpes sospecharon de �ste. Despu�s arrib� el due�o de la vivienda.

Sin embargo las autoridades competentes, se�alaron que una vez que al 911 reportaron el hallazgo de la mujer sin vida, acudieron preventivos para entrevistarse con el due�o de la finca, mismo que refiri� tenerla abandonada efectivamente pero de vez en cuando va a revisarla, y esta vez se llev� la sorpresa del cad�ver en una de las habitaciones. Agregando los polic�s que no hab� sangre en el sitio donde qued� la joven, por lo que dieron parte al Ministerio P�blico de turno',null,null,null);
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('31','https://www.diariopresente.mx/sucesos/capturan-a-sujeto-por-feminicidio-en-cunduacan/205793','12/02/2018','La madre se neg� a entregarle lo que ped�a

FacebookTwitterWhatsAppCorreoCopy Link
Cunduac�n.- Sujeto originario del ejido Ceiba primera secci�n fue detenido por la Polic�a Municipal, luego que con once certeras pu�aladas le diera muerte a su progenitora, al parecer porque �sta se neg� a darle dinero para seguir en la parranda.

Seg�n informes policiales, a eso de las 21:00 horas de este domingo, elementos de la Polic�a Municipal Preventiva fueron alertados que en el hospital regional hab�an ingresado a una mujer ya muerta.

Por este motivo, un grupo de uniformados se desplazaron hasta el lugar de los hechos y ah� se entrevistaron con Francisco A., B., quien dijo ser el cu�ado de la occisa Mar�a Reyes �N�, la cual hab�a sido victimada a pu�aladas por su propio hijo. E inclusive el matricida hab�a llegado al Hospital Regional, donde fue localizado por Elementos de la Direcci�n de Seguridad P�blica local y llevado a los separos.

Sobre la forma en que perdi� la vida la ama de casa, se refiere que �sta se encontraba descansando cuando lleg� su hijo David Concepci�n M. de 23 a�os, quien se encontraba bajo los efectos del alcohol y posiblemente alguna droga, le comenz� a exigir dinero para seguir en la parranda.

No obstante, como �sta se neg� a entregarle lo que ped�a, David se dirigi� a la cocina donde tom� un cuchillo con el que la atac� hasta que cay� mortalmente herida al suelo, donde fue encontrada por otro de sus hijos, quien la llev� r�pidamente al nosocomio pero �sta muri� antes de ser ingresada.','Los Femicidios en Mexico',null,null);
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('33','https://www.msn.com/es-mx/noticias/mexico/hallan-sin-vida-a-la-maestra-aida-rodr%C3%ADguez-campa%C3%B1a-en-sinaloa/ar-BBPptaK','06/11/2018','El cad�ver fue hallado en la zona de Caimero, en la ciudad de Mocorito; ah�, llegaron elementos de urgencia y de investigaci�n para recoger el cuerpo y comenzar el an�lisis para determinar las causas de muerte.',null,null,null);
Insert into FEMICIDIOS.NOTICIA (ID_NOTICIA,URL,FECHA_UR,TEXTOCOMPLETO_URL,AUTOR,CATEGORIA,PALABRAS) values ('34','https://feminicidiosmx.crowdmap.com/reports/view/4525','04/11/2018','Freddy Mej�a / Tribuna de San Luis Lunes 6 de noviembre de 2017 en Polic�aca
SLRC.- Alberto �N�, de 38 a�os de edad y Gloria Karina �N�, de 36 hoy ser�n acusados por el fiscal ante el Juez de Control del delito de feminicidio por la muerte por estrangulamiento de la joven Jessica Lizeth Ledezma Acosta, cuyos hechos se registraron el pasado s�bado en un domicilio de la avenida Santo Domingo y calle San Alberto, colonia Aviaci�n 2.

Como se informara, ambos fueron arrestados al ser sorprendidos quemando el cuerpo de Ledezma, que hab�an introducido en un agujero en el patio.
El fuego solo alcanz� a afectar las piernas por la oportuna llegada de elementos de la Direcci�n de Polic�a y Tr�nsito, y Agencia Ministerial de Investigaci�n Criminal.
PUBLICIDAD



Los uniformados hab�an sido enterados por un testigo en torno a que �La Gloria� le hab�a manifestado que por la avenida San Francisco y calle San Felipe, frente a una tienda de abarrotes y como al mediod�a hab�an levantado a �La Jessi� y la hab�an asesinado en la casa de �El Beto�.

Fue as� como r�pidamente se organiz� el operativo mediante el que la pareja fue sorprendida echando mas le�a a la hoguera que hab�an hecho en el patio, con intenci�n de desaparecer el cuerpo.
Para los vecinos fue sorpresiva la acci�n polic�aca a causa de que la vivienda casi no era habitada por �El Beto�, quien hace tiempo se hab�a separado de su esposa.

Durante las investigaciones no se ha podido establecer bien la causa del crimen, aunque la polic�a sospecha que fue por problemas a�ejos entre �La Gloria� y �La Jessi�.
Hasta ayer tarde no se conoc�a la hora exacta de la audiencia en la Primera Sala Oral en la que ser� acusada la pareja por el delito de feminicidio.',null,null,null);
REM INSERTING into FEMICIDIOS.NOTICIA_FEMICIDIO
SET DEFINE OFF;
REM INSERTING into FEMICIDIOS.PAIS
SET DEFINE OFF;
Insert into FEMICIDIOS.PAIS (ID_PAIS,PAIS) values ('1','Mexico');
REM INSERTING into FEMICIDIOS.PALABRAS
SET DEFINE OFF;
Insert into FEMICIDIOS.PALABRAS (ID_PALABRAS,COLUMN1) values ('1','Femicidio');
Insert into FEMICIDIOS.PALABRAS (ID_PALABRAS,COLUMN1) values ('2','Asesinato');
Insert into FEMICIDIOS.PALABRAS (ID_PALABRAS,COLUMN1) values ('3','Homicidio');
Insert into FEMICIDIOS.PALABRAS (ID_PALABRAS,COLUMN1) values ('4','Trajedia');
REM INSERTING into FEMICIDIOS.PROVINCIAS
SET DEFINE OFF;
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('1','Yucat�n');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('2','Coahuila de Zaragoza');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('3','Guanajuato');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('4','Nuevo Le�n');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('5','Tamaulipas');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('6','Oaxaca');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('7','Chiapas');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('8','Puebla');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('9','Veracruz de Ignacio de la Llave');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('10','M�xico');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('11','Nayarit');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('12','Guerrero');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('13','Jalisco');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('14','Hidalgo');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('15','Sonora');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('16','Tlaxcala');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('17','Michoac�n de Ocampo');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('18','Aguascalientes');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('19','Sinaloa');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('20','San Luis Potos�');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('21','Chihuahua');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('22','Distrito Federal');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('23','Colima');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('24','Tabasco');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('25','Quintana Roo');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('26','Campeche');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('27','Durango');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('28','Baja California Sur');
Insert into FEMICIDIOS.PROVINCIAS (ID_PROVINCIA,PROVINCIA) values ('29','Baja California');
REM INSERTING into FEMICIDIOS.VICTIMA
SET DEFINE OFF;
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('1','Maria','Reyes',null,'Mexicano','Desconocido');
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('2','Gabriela','N','22 ','Mexicana',' venta de estupefacientes de manera independiente');
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('3','A�da','Rodr�guez Campa�a ','38 ','Mexicana','Maestra');
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('4','Ingrid','Alison','14 ','Mexiacana',null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('5','Melissa Abigail',null,'19 ','Mexicana',null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('6',null,null,'31','Mexicana','Auxiliar Administrativa');
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('7',null,null,null,'Mexicana','Funcionaria');
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('8',null,null,null,'Mexicana','Funcionaria');
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('9',null,null,null,'Mexicana','Funcionaria');
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('10',null,null,'20','Mexicana','Auxiliar Administrativa');
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('11',null,null,'27','Mexicana','Auxiliar Administrativa');
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('12',' Jessica Lizeth','Ledezma Acosta','17','Mexicana',null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('13','Maria','N','14','Mexiacana',null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('14','Desconocido','Desconocido','12',null,null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('15','Claudia','Hernandez Fonseca',null,'Mexicana',null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('16','Jessica','Serrano','16 ','Mexicana','Estudiante');
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('17',null,null,null,null,null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('18','Angeles','Cavita','52 ','Mexicana',null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('19',null,null,'28 ',null,null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('20','Betty',' Lazcano','40 ','Mexicana',null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('21','G�nesis ','Gibson','24 ','Mexicana',null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('22',null,null,null,null,null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('23',' Mar� del Carmen','Salas P�rez','26 ','Mexicana',null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('24','Angelina','G.G','30 ','Mexicana',null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('25','Cristina','R.S','30 ','Mexicana',null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('26','Elizabeth',null,'24 ','Mexicana',null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('27',null,null,null,null,null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('28',' Karen Mar� Luisa','Z�rraga Almaraz','22 ','Mexicana',null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('29','Mar� Guadalupe ','Z�rraga Almaraz','18 ','Mexicana',null);
Insert into FEMICIDIOS.VICTIMA (ID_VICTIMA,NOMBRE_VICTIMA,APELLIDOS_VICTIMA,EDAD_VICTIMA,NACIONALIDAD_VICTIMA,OCUPACION_VICTIMA) values ('30','Angelica',null,null,null,null);
REM INSERTING into FEMICIDIOS.VITIMA_AGRESOR
SET DEFINE OFF;
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('3','3','3','Esposo',null,'La maestra de historia hab�a solicitado ser cambiada de plantel ya que su exmarido viv�a ah� y la amenazaba. Pese a sentirse en peligro, le fue negada la solicitud.');
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('4','4','4','Amiga',null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('5','5','5','Ninguna',null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('6','6','6','Esposo',null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('7','7','7','Ninguna',null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('8','8','8','Esposo',null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('9','9','9','Ninguna',null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('10','10','10','Ninguna',null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('11','11','11','Ninguna',null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('12','12','12','Ninguna',null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('13','13','13',null,null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('14','14','14',null,null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('15','15','15',null,null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('16','16','16',null,null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('17','17','17',null,null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('18','18','18','Esposo',null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('19','19','19',null,null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('20','20','20',null,null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('21','21','21',null,null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('22','22','22',null,null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('23','23','23',null,null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('24','24','24',null,null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('25','25','25',null,null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('26','26','26',null,null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('27','27','27',null,null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('28','28','28',null,null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('29','29','29',null,null,null);
Insert into FEMICIDIOS.VITIMA_AGRESOR (ID_VICTIMA_AGRESOR,ID_VICTIMA,ID_AGRESOR,"RELACI�N_V�CTIMA","TIEMPO_RELACI�N",AGRESION_PREVIA) values ('30','30','30',null,null,null);
--------------------------------------------------------
--  DDL for Index DEPARTAMENTO_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "FEMICIDIOS"."DEPARTAMENTO_PK" ON "FEMICIDIOS"."DEPARTAMENTO" ("ID_DEPARTAMENTO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index PAIS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "FEMICIDIOS"."PAIS_PK" ON "FEMICIDIOS"."PAIS" ("ID_PAIS") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index JUICIO_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "FEMICIDIOS"."JUICIO_PK" ON "FEMICIDIOS"."JUICIO" ("NRO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index VITIMA_AGRESOR_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "FEMICIDIOS"."VITIMA_AGRESOR_PK" ON "FEMICIDIOS"."VITIMA_AGRESOR" ("ID_VICTIMA_AGRESOR") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index PROVINCIAS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "FEMICIDIOS"."PROVINCIAS_PK" ON "FEMICIDIOS"."PROVINCIAS" ("ID_PROVINCIA") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index FEMICIDIO_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "FEMICIDIOS"."FEMICIDIO_PK" ON "FEMICIDIOS"."FEMICIDIO" ("ID_FEMICIDIO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index NOTICIA_FEMICIDIO_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "FEMICIDIOS"."NOTICIA_FEMICIDIO_PK" ON "FEMICIDIOS"."NOTICIA_FEMICIDIO" ("ID_NOTICIA_FEMICIDIO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index VICTIMA_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "FEMICIDIOS"."VICTIMA_PK" ON "FEMICIDIOS"."VICTIMA" ("ID_VICTIMA") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index BARRIO_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "FEMICIDIOS"."BARRIO_PK" ON "FEMICIDIOS"."BARRIO" ("ID_BARRIO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index PALABRAS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "FEMICIDIOS"."PALABRAS_PK" ON "FEMICIDIOS"."PALABRAS" ("ID_PALABRAS") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index AGRESOR_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "FEMICIDIOS"."AGRESOR_PK" ON "FEMICIDIOS"."AGRESOR" ("ID_AGRESOR") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  Constraints for Table NOTICIA_FEMICIDIO
--------------------------------------------------------

  ALTER TABLE "FEMICIDIOS"."NOTICIA_FEMICIDIO" ADD CONSTRAINT "NOTICIA_FEMICIDIO_PK" PRIMARY KEY ("ID_NOTICIA_FEMICIDIO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "FEMICIDIOS"."NOTICIA_FEMICIDIO" MODIFY ("ID_NOTICIA_FEMICIDIO" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table NOTICIA
--------------------------------------------------------

  ALTER TABLE "FEMICIDIOS"."NOTICIA" ADD PRIMARY KEY ("ID_NOTICIA")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "FEMICIDIOS"."NOTICIA" MODIFY ("ID_NOTICIA" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table JUICIO
--------------------------------------------------------

  ALTER TABLE "FEMICIDIOS"."JUICIO" ADD CONSTRAINT "JUICIO_PK" PRIMARY KEY ("NRO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "FEMICIDIOS"."JUICIO" MODIFY ("NRO" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table VICTIMA
--------------------------------------------------------

  ALTER TABLE "FEMICIDIOS"."VICTIMA" ADD CONSTRAINT "VICTIMA_PK" PRIMARY KEY ("ID_VICTIMA")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "FEMICIDIOS"."VICTIMA" MODIFY ("ID_VICTIMA" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table AGRESOR
--------------------------------------------------------

  ALTER TABLE "FEMICIDIOS"."AGRESOR" ADD CONSTRAINT "AGRESOR_PK" PRIMARY KEY ("ID_AGRESOR")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "FEMICIDIOS"."AGRESOR" MODIFY ("ID_AGRESOR" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table DEPARTAMENTO
--------------------------------------------------------

  ALTER TABLE "FEMICIDIOS"."DEPARTAMENTO" ADD CONSTRAINT "DEPARTAMENTO_PK" PRIMARY KEY ("ID_DEPARTAMENTO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "FEMICIDIOS"."DEPARTAMENTO" MODIFY ("ID_DEPARTAMENTO" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table PAIS
--------------------------------------------------------

  ALTER TABLE "FEMICIDIOS"."PAIS" ADD CONSTRAINT "PAIS_PK" PRIMARY KEY ("ID_PAIS")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "FEMICIDIOS"."PAIS" MODIFY ("ID_PAIS" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table VITIMA_AGRESOR
--------------------------------------------------------

  ALTER TABLE "FEMICIDIOS"."VITIMA_AGRESOR" ADD CONSTRAINT "VITIMA_AGRESOR_PK" PRIMARY KEY ("ID_VICTIMA_AGRESOR")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "FEMICIDIOS"."VITIMA_AGRESOR" MODIFY ("ID_VICTIMA_AGRESOR" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table PALABRAS
--------------------------------------------------------

  ALTER TABLE "FEMICIDIOS"."PALABRAS" ADD CONSTRAINT "PALABRAS_PK" PRIMARY KEY ("ID_PALABRAS")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "FEMICIDIOS"."PALABRAS" MODIFY ("ID_PALABRAS" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table FEMICIDIO
--------------------------------------------------------

  ALTER TABLE "FEMICIDIOS"."FEMICIDIO" ADD CONSTRAINT "FEMICIDIO_PK" PRIMARY KEY ("ID_FEMICIDIO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "FEMICIDIOS"."FEMICIDIO" MODIFY ("ID_FEMICIDIO" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table PROVINCIAS
--------------------------------------------------------

  ALTER TABLE "FEMICIDIOS"."PROVINCIAS" ADD CONSTRAINT "PROVINCIAS_PK" PRIMARY KEY ("ID_PROVINCIA")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "FEMICIDIOS"."PROVINCIAS" MODIFY ("ID_PROVINCIA" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table BARRIO
--------------------------------------------------------

  ALTER TABLE "FEMICIDIOS"."BARRIO" ADD CONSTRAINT "BARRIO_PK" PRIMARY KEY ("ID_BARRIO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "FEMICIDIOS"."BARRIO" MODIFY ("ID_BARRIO" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table FEMICIDIO
--------------------------------------------------------

  ALTER TABLE "FEMICIDIOS"."FEMICIDIO" ADD CONSTRAINT "DEPARTAMENTO_FK4" FOREIGN KEY ("ID_DEPARTAMENTO")
	  REFERENCES "FEMICIDIOS"."DEPARTAMENTO" ("ID_DEPARTAMENTO") ENABLE;
  ALTER TABLE "FEMICIDIOS"."FEMICIDIO" ADD CONSTRAINT "ID_BARRIO_FK3" FOREIGN KEY ("ID_BARRIO")
	  REFERENCES "FEMICIDIOS"."BARRIO" ("ID_BARRIO") ENABLE;
  ALTER TABLE "FEMICIDIOS"."FEMICIDIO" ADD CONSTRAINT "PAIS_FK2" FOREIGN KEY ("ID_PAIS")
	  REFERENCES "FEMICIDIOS"."PAIS" ("ID_PAIS") ENABLE;
  ALTER TABLE "FEMICIDIOS"."FEMICIDIO" ADD CONSTRAINT "PROVINCIA_FK1" FOREIGN KEY ("ID_PROVINCIA")
	  REFERENCES "FEMICIDIOS"."PROVINCIAS" ("ID_PROVINCIA") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table JUICIO
--------------------------------------------------------

  ALTER TABLE "FEMICIDIOS"."JUICIO" ADD CONSTRAINT "FEMICIDIO_FK1" FOREIGN KEY ("FEMICIDIO")
	  REFERENCES "FEMICIDIOS"."FEMICIDIO" ("ID_FEMICIDIO") ENABLE;
  ALTER TABLE "FEMICIDIOS"."JUICIO" ADD CONSTRAINT "VICTIMA_AGRESOR_FK1" FOREIGN KEY ("VICTIMA_AGRESOR")
	  REFERENCES "FEMICIDIOS"."VITIMA_AGRESOR" ("ID_VICTIMA_AGRESOR") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table NOTICIA
--------------------------------------------------------

  ALTER TABLE "FEMICIDIOS"."NOTICIA" ADD CONSTRAINT "PALABRAS_FK1" FOREIGN KEY ("PALABRAS")
	  REFERENCES "FEMICIDIOS"."PALABRAS" ("ID_PALABRAS") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table NOTICIA_FEMICIDIO
--------------------------------------------------------

  ALTER TABLE "FEMICIDIOS"."NOTICIA_FEMICIDIO" ADD CONSTRAINT "FEMICIDIO_FK" FOREIGN KEY ("FEMICIDIO")
	  REFERENCES "FEMICIDIOS"."FEMICIDIO" ("ID_FEMICIDIO") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table VITIMA_AGRESOR
--------------------------------------------------------

  ALTER TABLE "FEMICIDIOS"."VITIMA_AGRESOR" ADD CONSTRAINT "AGRESOR_FK" FOREIGN KEY ("ID_AGRESOR")
	  REFERENCES "FEMICIDIOS"."AGRESOR" ("ID_AGRESOR") ENABLE;
  ALTER TABLE "FEMICIDIOS"."VITIMA_AGRESOR" ADD CONSTRAINT "VITIMA_FK1" FOREIGN KEY ("ID_VICTIMA")
	  REFERENCES "FEMICIDIOS"."VICTIMA" ("ID_VICTIMA") ENABLE;
